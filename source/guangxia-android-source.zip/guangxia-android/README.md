# 光匣 · 离线相机档案（Android）

「光匣」的手机 APK 演示版。界面与数据逻辑全部内置在 APK 的 `assets/index.html` 中，不依赖任何网络资源。

## APK

- 文件：`../光匣-离线版.apk`
- 大小：约 113 KB
- SHA-256：`9FC65D2118BAD7335229868ED9755229FC4498914990DA534D8F2286EF0B6AC9`

## 基本信息

| 项目 | 内容 |
| --- | --- |
| 应用名 | 光匣 |
| 包名 | `com.guangxia.app` |
| 版本 | 2.0（versionCode 3，视觉更新版） |
| 最低系统 | Android 8.0（API 26） |
| 目标系统 | Android 14（API 34） |
| 编译 SDK | Android 15（API 35） |
| 网络权限 | 无 |
| 数据存储 | WebView localStorage + IndexedDB，本机保存 |
| 签名 | APK Signature Scheme v2 / v3，自签名 |

## 功能

- 首次打开输入用户名完成本地注册，并说明离线与存储方式。
- 内置 286 台可换镜头相机：尼康 / 佳能 / 索尼 / 哈苏，覆盖胶片、数码单反、微单与中画幅。
- 相机以简约线条画卡片展示，可切换横向 / 竖向排布。
- 相机详情：简介、画幅、卡口、发布年份。
- 胶片机先选胶卷再放照片；内置五大品牌 76 种胶卷，支持自定义名字、毫米数、彩色 / 黑白。
- 每台相机可批量导入照片原图，原图完整保存在本机；胶片机按胶卷分组。
- 相机详情页可直接单张删除照片，或一键删除该相机的全部照片；胶卷会保留为空卷。
- 照片全屏查看，可左右切换、替换原图、分享原图、删除，操作前确认。
- 分享优先走 Android 系统分享（内置轻量 ContentProvider 共享缓存图片），系统分享不可用时保存原图。
- 本地档案页支持改名、查看存储信息、复制反馈邮箱、清空全部数据。
- 反馈 / 建议邮箱：`3178881099@qq.com`。
- Android 返回键优先关闭当前弹层；没有弹层时退出 App。

## 安装

1. 把 `光匣-离线版.apk` 传到 Android 手机。
2. 点击安装，按系统提示允许「安装未知来源应用」。
3. APK 使用自签名证书，部分手机会提示未经过应用市场验证，这是正常的。

支持 Android 8.0 及以上。不同厂商对 WebView 的更新策略不同；如果页面显示异常，请在应用商店更新「Android System WebView」或 Chrome。

## 数据说明

- 用户名、相机、照片原图与排布偏好只保存在本机应用的 WebView 存储中。
- App 不申请 INTERNET 权限，不会上传任何数据。
- 卸载 App、在系统设置中清除应用数据，都会永久删除这些内容。
- 为了保持同源存储的稳定性，页面通过固定的 `https://guangxia.local` 源加载，并在 `WebViewClient.shouldInterceptRequest` 中直接从 APK assets 返回 HTML；不会发起真实网络请求。

## 重新构建

需要：JDK 17、Android SDK Platform 35、Build-Tools。

推荐直接在 Android Studio 打开本目录，或设置好 `JAVA_HOME` 与 `ANDROID_HOME` 后执行：

```powershell
# 把最新的 HTML 复制进 Android assets 并构建、对齐、签名
.\build-release.ps1
```

脚本会：
1. 复制上一级目录的 `光匣-离线相机档案.html` 到 `app/src/main/assets/index.html`；
2. 执行 `gradlew.bat assembleRelease`；
3. 用 Build-Tools 的 `zipalign` 与 `apksigner` 生成签名 APK；
4. 输出到 `../光匣-离线版.apk`。

## 签名文件

公开源码包不包含签名私钥，也不会包含 `keystore.properties`。如需自行构建，请在本机创建自己的 `keystore/` 配置，并在 `keystore.properties` 中填写签名信息。不要把 `.jks`、密码或 `keystore.properties` 提交到公开仓库。

更新已安装的 App 必须继续使用同一个签名证书；请自行备份签名文件。

## 结构

```
guangxia-android/
├─ app/src/main/assets/index.html   # 网页本体（由根目录 HTML 复制）
├─ app/src/main/java/com/guangxia/app/MainActivity.java
├─ app/src/main/java/com/guangxia/app/ShareFileProvider.java
├─ app/src/main/res/                # 图标、主题、字符串
├─ build-release.ps1                # 构建 + 对齐 + 签名
├─ gradle/ gradlew gradlew.bat      # Gradle wrapper
├─ keystore/                        # 自签名证书
└─ README.md
```
