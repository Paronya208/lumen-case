package com.guangxia.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {

    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final String APP_HOST = "guangxia.local";
    private static final String APP_URL = "https://" + APP_HOST + "/index.html";
    private static final String PAPER = "#F2EEE4";
    private static final String INK = "#20201B";

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureSystemBars();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor(PAPER));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setTextZoom(100);
        settings.setLoadsImagesAutomatically(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.addJavascriptInterface(new AndroidBridge(), "GuangxiaAndroid");

        // 用一个固定的 https 源加载内置页面：
        // 这样 localStorage / IndexedDB 会拥有稳定、可持久化的同源存储；
        // 页面本身仍从 APK assets 读取，不产生任何网络请求。
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri != null && APP_HOST.equals(uri.getHost())) {
                    String path = uri.getPath();
                    if (path == null || "/".equals(path) || "/index.html".equals(path)) {
                        return serveIndex();
                    }
                    return emptyResponse(404, "Not Found");
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri == null) return true;
                if (APP_HOST.equals(uri.getHost())) return false;
                if ("mailto".equalsIgnoreCase(uri.getScheme())) {
                    openMail(uri);
                    return true;
                }
                // The archive is offline; do not let it navigate away.
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             WebChromeClient.FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                }
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    if (params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) {
                        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    }
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException error) {
                    filePathCallback = null;
                    return false;
                }
            }
        });

        webView.loadUrl(APP_URL);
        setContentView(webView);
    }

    private WebResourceResponse serveIndex() {
        try {
            InputStream stream = getAssets().open("index.html");
            Map<String, String> headers = new HashMap<>();
            headers.put("Cache-Control", "no-store");
            headers.put("Content-Type", "text/html; charset=utf-8");
            return new WebResourceResponse("text/html", "UTF-8",
                    200, "OK", headers, stream);
        } catch (IOException error) {
            return emptyResponse(500, "Internal Server Error");
        }
    }

    private WebResourceResponse emptyResponse(int statusCode, String reason) {
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "text/plain; charset=utf-8");
        return new WebResourceResponse("text/plain", "UTF-8",
                statusCode, reason, headers, new ByteArrayInputStream(new byte[0]));
    }

    private void openMail(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_SENDTO, uri));
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "没有找到邮件应用", Toast.LENGTH_SHORT).show();
        }
    }

    private String sanitizeShareName(String fileName) {
        String name = fileName == null ? "" : fileName.trim();
        if (name.isEmpty()) name = "guangxia.jpg";
        name = name.replaceAll("[\\\\/:*?\"<>|\\r\\n]", "_");
        if (name.length() > 80) {
            int dot = name.lastIndexOf('.');
            String extension = (dot > 0 && name.length() - dot <= 8) ? name.substring(dot) : "";
            int keep = Math.max(1, 80 - extension.length());
            name = name.substring(0, keep) + extension;
        }
        if (!name.matches(".*\\.[A-Za-z0-9]{1,6}$")) {
            name += ".jpg";
        }
        return name;
    }

    private void cleanupOldShares(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return;
        long cutoff = System.currentTimeMillis() - 24L * 60L * 60L * 1000L;
        for (File file : files) {
            if (file.isFile() && file.lastModified() < cutoff) {
                // Best effort: a cache file that cannot be removed is harmless.
                file.delete();
            }
        }
    }

    private class AndroidBridge {

        @JavascriptInterface
        public String shareImage(String base64, String fileName, String mimeType, String title) {
            if (base64 == null || base64.isEmpty()) return "error:empty";
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                if (bytes.length == 0) return "error:empty";

                File dir = new File(getCacheDir(), ShareFileProvider.CACHE_DIR);
                if (!dir.exists() && !dir.mkdirs()) return "error:cache";
                cleanupOldShares(dir);

                String safeName = sanitizeShareName(fileName);
                File file = new File(dir, safeName);
                try (FileOutputStream output = new FileOutputStream(file)) {
                    output.write(bytes);
                }

                Uri uri = Uri.parse("content://" + ShareFileProvider.AUTHORITY + "/" + Uri.encode(safeName));
                String type = (mimeType == null || mimeType.trim().isEmpty())
                        ? "image/jpeg" : mimeType.trim();
                String subject = (title == null || title.trim().isEmpty())
                        ? "光匣照片" : title.trim();

                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(type);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_SUBJECT, subject);
                send.putExtra(Intent.EXTRA_TEXT, subject);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                runOnUiThread(() -> {
                    try {
                        Intent chooser = Intent.createChooser(send, "分享原图");
                        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(chooser);
                    } catch (ActivityNotFoundException error) {
                        Toast.makeText(MainActivity.this, "没有可用的分享应用", Toast.LENGTH_SHORT).show();
                    } catch (Exception error) {
                        Toast.makeText(MainActivity.this, "分享失败，请重试", Toast.LENGTH_SHORT).show();
                    }
                });
                return "ok";
            } catch (Exception error) {
                return "error:share";
            }
        }

        @JavascriptInterface
        public boolean copyText(String text) {
            if (text == null) return false;
            try {
                ClipboardManager clipboard =
                        (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard == null) return false;
                clipboard.setPrimaryClip(ClipData.newPlainText("光匣", text));
                return true;
            } catch (Exception error) {
                return false;
            }
        }
    }

    private void configureSystemBars() {
        getWindow().setStatusBarColor(Color.parseColor(PAPER));
        int flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getWindow().setNavigationBarColor(Color.parseColor(PAPER));
            flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        } else {
            getWindow().setNavigationBarColor(Color.parseColor(INK));
        }
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        // 先交给网页关闭弹层；没有弹层时再退出 App。
        webView.evaluateJavascript(
                "(function(){try{return window.__GUANGXIA_BACK__ ? window.__GUANGXIA_BACK__() : false;}catch(e){return false;}})()",
                value -> {
                    if (!"true".equals(value)) {
                        finish();
                    }
                });
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
