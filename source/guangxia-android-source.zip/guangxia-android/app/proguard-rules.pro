# Keep WebView-related entry points reachable if minification is enabled later.
-keepclassmembers class com.guangxia.app.MainActivity {
    public *;
}
