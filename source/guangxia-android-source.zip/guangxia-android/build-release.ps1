﻿[CmdletBinding()]
param(
    [string]$Html = (Join-Path $PSScriptRoot '..\光匣-离线相机档案.html'),
    [string]$Output = (Join-Path $PSScriptRoot '..\光匣-离线版.apk'),
    [string]$JdkHome = $env:JAVA_HOME,
    [string]$SdkRoot = $env:ANDROID_HOME
)

$ErrorActionPreference = 'Stop'

if (-not $JdkHome) { $JdkHome = $env:JAVA_HOME }
if (-not $SdkRoot) { $SdkRoot = $env:ANDROID_SDK_ROOT }
if (-not $JdkHome -or -not (Test-Path (Join-Path $JdkHome 'bin\java.exe'))) {
    throw '请设置 JAVA_HOME 指向 JDK 17。'
}
if (-not $SdkRoot -or -not (Test-Path $SdkRoot)) {
    throw '请设置 ANDROID_HOME 指向 Android SDK。'
}

$env:JAVA_HOME = $JdkHome
$env:ANDROID_HOME = $SdkRoot
$env:ANDROID_SDK_ROOT = $SdkRoot
if (-not $env:GRADLE_USER_HOME) {
    $env:GRADLE_USER_HOME = Join-Path $PSScriptRoot '.gradle-user'
}
if (-not $env:ANDROID_USER_HOME) {
    $env:ANDROID_USER_HOME = Join-Path $PSScriptRoot '.android-user'
}

$htmlPath = [System.IO.Path]::GetFullPath($Html)
$outputPath = [System.IO.Path]::GetFullPath($Output)
$assetPath = Join-Path $PSScriptRoot 'app\src\main\assets\index.html'

if (-not (Test-Path $htmlPath)) {
    if (Test-Path $assetPath) {
        $htmlPath = $assetPath
        Write-Host '未找到外部 HTML，使用项目内置的 assets/index.html。'
    } else {
        throw "找不到 HTML：$htmlPath"
    }
}
if ($htmlPath -ne $assetPath) {
    Copy-Item -LiteralPath $htmlPath -Destination $assetPath -Force
    Write-Host "已复制 HTML → $assetPath"
}

# 构建工具会写临时目录；放在项目内，避免系统临时目录权限问题。
$buildTmp = Join-Path $PSScriptRoot '.tmp-build'
New-Item -ItemType Directory -Force $buildTmp | Out-Null
New-Item -ItemType Directory -Force $env:ANDROID_USER_HOME | Out-Null
$env:TMP = $buildTmp
$env:TEMP = $buildTmp
if (-not $env:JAVA_TOOL_OPTIONS) {
    $env:JAVA_TOOL_OPTIONS = "-Djava.io.tmpdir=$buildTmp"
}
Remove-Item Env:ANDROID_PREFS_ROOT -ErrorAction SilentlyContinue

& (Join-Path $PSScriptRoot 'gradlew.bat') -p $PSScriptRoot assembleRelease --no-daemon
if ($LASTEXITCODE -ne 0) { throw 'Gradle 构建失败。' }

$unsigned = Join-Path $PSScriptRoot 'app\build\outputs\apk\release\app-release-unsigned.apk'
if (-not (Test-Path $unsigned)) { throw '找不到未签名 APK。' }

$buildTools = Get-ChildItem (Join-Path $SdkRoot 'build-tools') -Directory |
    Sort-Object { try { [version]$_.Name } catch { [version]'0.0.0' } } -Descending |
    Select-Object -First 1
if (-not $buildTools) { throw '找不到 Android Build-Tools。' }

$zipalign = Join-Path $buildTools.FullName 'zipalign.exe'
$apksigner = Join-Path $buildTools.FullName 'apksigner.bat'
$aligned = Join-Path ([System.IO.Path]::GetTempPath()) 'guangxia-aligned.apk'
if (Test-Path $aligned) { Remove-Item $aligned -Force }
if (Test-Path $outputPath) { Remove-Item $outputPath -Force }

& $zipalign -p -f 4 $unsigned $aligned
if ($LASTEXITCODE -ne 0) { throw 'zipalign 失败。' }

$propertiesPath = Join-Path $PSScriptRoot 'keystore\keystore.properties'
$properties = @{}
Get-Content -LiteralPath $propertiesPath | ForEach-Object {
    if ($_ -match '^\s*([^#=]+?)\s*=\s*(.*?)\s*$') {
        $properties[$matches[1]] = $matches[2]
    }
}
$keystore = Join-Path $PSScriptRoot $properties['storeFile']
if (-not (Test-Path $keystore)) { throw "找不到签名文件：$keystore" }

& $apksigner sign `
    --ks $keystore `
    --ks-key-alias $properties['keyAlias'] `
    --ks-pass ('pass:' + $properties['storePassword']) `
    --key-pass ('pass:' + $properties['keyPassword']) `
    --out $outputPath $aligned
if ($LASTEXITCODE -ne 0) { throw 'apksigner 签名失败。' }

& $apksigner verify --verbose $outputPath
if ($LASTEXITCODE -ne 0) { throw 'APK 签名校验失败。' }

Remove-Item $aligned -Force -ErrorAction SilentlyContinue
Write-Host ''
Write-Host "打包完成：$outputPath"
Get-Item $outputPath | Select-Object Name, Length, LastWriteTime
Get-FileHash $outputPath -Algorithm SHA256 | Select-Object Algorithm, Hash
